# At home Internet Setup

From modem to router to wireless to connectivity.

## Modem

Secure a coaxial line from the Internet Service Provider to the modem.

Use a device with an Ethernet port and web browser, connect via an ethernet cable, to access the modem's settings and log.

The device may need to declare an IP address within the first octets of the modem's, follow the IP address given on the bottom sticker.

For Netgear CM1000v2, modem is 192.168.100.1

## Router

For initial setup, use a device with an Ethernet port and web browser, connect via an ethernet cable, to access the router settings.

Use ip/fconfig to see the requested address from the router, then declare an IP address within the first octets.

### Ubiquiti Edge Router X

By default
- eth1 is a DHCP client, eth0 is assigned 192.168.1.1
- username and password is ubnt

#### Setup Wizard

Internet on port eth4, from the modem.

DHCP
- automatically obtain network settings from the Internet Service Provider
- enable firewalls

Configure Domain Name Servers
1. 1.1.1.1
1. 9.9.9.9 (Quad9)

Enable DHCP
 
## My Setup

### CM1000v2

Assigned 192.168.100.1




### Edgerouter (ER-X)

Username: ubnt
Password: S9184d24

Assigned 192.168.100.2

System host name: EdgeRouter-X-5-Port

### Airport Extreme

Assigned 192.168.102.1

Network Name: TheBungalo_IoT
Password: apple

System host name: TheBungalo_IoT